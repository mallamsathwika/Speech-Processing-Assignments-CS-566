#include "stdafx.h"         // needed for Visual Studio precompiled headers
#include <iostream>
#include <fstream>
#include <string>
#include <conio.h>
#include <math.h>
using namespace std;

#define FRAME_MS        20      // frame length in ms
#define INITFRAMES      10      // number of initial frames to estimate noise
#define AMPSCALE        5000.0  // scale samples for processing
#define PREEMPH         0.97    // pre-emphasis factor
#define ZCR_EPS         5.0     // ignore tiny crossings around zero

#pragma pack(push, 1)
// WAV header structure (16-bit PCM expected)
struct WAVHeader {
    char riff[4];
    unsigned int overall_size;
    char wave[4];
    char fmt_chunk_marker[4];
    unsigned int length_of_fmt;
    unsigned short format_type;
    unsigned short channels;
    unsigned int sample_rate;
    unsigned int byterate;
    unsigned short block_align;
    unsigned short bits_per_sample;
    char data_chunk_header[4];
    unsigned int data_size;
};
#pragma pack(pop)

// global variables for audio data
short* samples = 0;
long samplecount = 0;
double DCshift = 0.0;
short MaxAmp = 1;

double NoiseEnergy = 0.0, TotalZCR = 0.0;
double ThresholdEnergy = 0.0, ThresholdZCR = 0.0;

static inline int sgn(double x){ return (x>0)-(x<0); }

// read 16-bit PCM wav file into memory
bool readWavFile(const char* filename, int& samplerate)
{
    ifstream file(filename, ios::binary);
    if (!file) { cout << "Error opening file: " << filename << "\n"; return false; }

    WAVHeader h;
    file.read((char*)&h, sizeof(WAVHeader));
    if (file.gcount() != sizeof(WAVHeader)) { cout << "Invalid WAV header.\n"; return false; }
    if (h.format_type != 1 || h.bits_per_sample != 16) { cout << "Only 16-bit PCM WAV supported.\n"; return false; }

    samplerate = (int)h.sample_rate;
    int channels = (int)h.channels;
    long total_samples_all_channels = (long)(h.data_size / 2);
    if (total_samples_all_channels <= 0) { cout << "No audio data.\n"; return false; }

    short* raw = new short[total_samples_all_channels];
    file.read((char*)raw, h.data_size);
    file.close();

    // if stereo, convert to mono
    if (channels == 1) {
        samples = raw;
        samplecount = total_samples_all_channels;
    } else {
        long monoCount = total_samples_all_channels / channels;
        samples = new short[monoCount];
        for (long i=0, w=0; i<monoCount; ++i, w+=channels) samples[i] = raw[w];
        delete[] raw;
        samplecount = monoCount;
    }

    // compute DC shift and max amplitude
    long long sum = 0;
    MaxAmp = 1;
    for (long i=0;i<samplecount;++i){
        sum += samples[i];
        short a = (short)(samples[i] >= 0 ? samples[i] : -samples[i]);
        if (a > MaxAmp) MaxAmp = a;
    }
    DCshift = (double)sum / (double)samplecount;
    if (MaxAmp == 0) MaxAmp = 1;
    return true;
}

int main(){
    string filename;
    cout << "Enter wav filename: ";
    getline(cin, filename);

    int SAMPLERATE = 16000;
    if(!readWavFile(filename.c_str(), SAMPLERATE)){ _getch(); return 0; }

    // frame size in samples
    int FRAMESIZE = (int)((SAMPLERATE * FRAME_MS)/1000);
    if (FRAMESIZE < 80) FRAMESIZE = 80;
    long framecount = samplecount / FRAMESIZE;
    if (framecount <= 0){ cout << "Audio too short.\n"; delete[] samples; _getch(); return 0; }

    // feature arrays
    double* AvgZCR = new double[framecount];
    double* AvgEnergy = new double[framecount];
    double* Corr1     = new double[framecount];

    // compute features per frame
    for (long i=0;i<framecount;++i){
        double zcr = 0.0, energy = 0.0, num = 0.0, den = 0.0;
        double y_prev = 0.0;      // previous pre-emphasized sample
        double x_prev = 0.0;      // previous raw sample
        for (int j=0;j<FRAMESIZE;++j){
            long idx = i*FRAMESIZE + j;
            double x = ((double)samples[idx] - DCshift) * (AMPSCALE / (double)MaxAmp);
            double y = x - PREEMPH * x_prev;   // pre-emphasis

            // zero-crossings
            if (j>0){
                if ( (y > ZCR_EPS && y_prev < -ZCR_EPS) || (y < -ZCR_EPS && y_prev > ZCR_EPS) ) zcr += 1.0;
                num += (y * y_prev); // for correlation
            }
            den += (y * y);
            energy += y*y;
            y_prev = y;
            x_prev = x;
        }
        AvgZCR[i]   = zcr / (double)FRAMESIZE;     // normalized
        AvgEnergy[i]= energy / (double)FRAMESIZE;
        Corr1[i]    = (den > 1e-9) ? (num / den) : 0.0;  // lag-1 autocorr
    }

    // estimate noise from initial frames
    int initFrames = (framecount < INITFRAMES)?(int)framecount:INITFRAMES;
    NoiseEnergy = 0.0; TotalZCR = 0.0;
    for (int i=0;i<initFrames;++i){ TotalZCR += AvgZCR[i]; NoiseEnergy += AvgEnergy[i]; }
    double NoiseZCR = (initFrames>0)?(TotalZCR/initFrames):0.0;
    NoiseEnergy = (initFrames>0)?(NoiseEnergy/initFrames):0.0;

    // thresholds
    double ThLow  = NoiseEnergy * 3;
    double ThHigh = NoiseEnergy * 6;
    ThresholdEnergy = ThHigh;
    ThresholdZCR = NoiseZCR * 0.9;

    cout << "ThresholdEnergy = " << ThresholdEnergy << "\n";
    cout << "ThresholdZCR = " << ThresholdZCR << "\n";

    // simple VAD
    long start=-1, stop=-1; bool inSpeech=false; int lowCount=0;
    for (long i=0;i<framecount;++i){
        if (!inSpeech){
            if (AvgEnergy[i] > ThHigh){ inSpeech=true; start=i; lowCount=0; }
        } else {
            if (AvgEnergy[i] < ThLow) lowCount++; else lowCount=0;
            if (lowCount >= 3){ stop = i - lowCount; inSpeech=false; break; }
        }
    }
    if (inSpeech && stop < 0) stop = framecount - 1;
    if (start < 0 || stop < start){
        cout << "No speech detected.\n";
        delete[] AvgZCR; delete[] AvgEnergy; delete[] Corr1; delete[] samples;
        _getch(); return 0;
    }

    // collect features over detected speech
    long L = (stop - start + 1);
    double testavgE=0.0, testavgZ=0.0, avgCorr1=0.0;
    for (long i=start;i<=stop;++i){ testavgE+=AvgEnergy[i]; testavgZ+=AvgZCR[i]; avgCorr1+=Corr1[i]; }
    testavgE/=(double)L; testavgZ/=(double)L; avgCorr1/=(double)L;

    // reject if speech too short/long or too weak
    double speechDuration = (double)L * (double)FRAMESIZE / (double)SAMPLERATE;
    if (speechDuration < 0.10 || speechDuration > 4.0){
        cout << "No speech detected.\n";
        delete[] AvgZCR; delete[] AvgEnergy; delete[] Corr1; delete[] samples;
        _getch(); return 0;
    }
    if (testavgE < NoiseEnergy * 6.0){
        cout << "No speech detected.\n";
        delete[] AvgZCR; delete[] AvgEnergy; delete[] Corr1; delete[] samples;
        _getch(); return 0;
    }

    // measure start/end ZCR
    long third = (L/3)>1 ? (L/3) : 1;
    double headZ=0.0, tailZ=0.0;
    for (long i=0;i<third;++i){ headZ+=AvgZCR[start+i]; tailZ+=AvgZCR[stop-i]; }
    headZ/=(double)third; tailZ/=(double)third;

    // convert to crossings per frame
    double finalZCR   = testavgZ * (double)FRAMESIZE;
    double headZ_cpf  = headZ    * (double)FRAMESIZE;
    double tailZ_cpf  = tailZ    * (double)FRAMESIZE;

    // count frames with high ZCR
    int highCnt=0;
    const double HIGH_ZCR_CPF = 12.0;
    for (long i=start;i<=stop;++i){
        if (AvgZCR[i] * (double)FRAMESIZE >= HIGH_ZCR_CPF) highCnt++;
    }
    double fracHigh = (double)highCnt / (double)L;

    // show extracted features
    cout << "Speech detected from " << (start*(double)FRAMESIZE)/(double)SAMPLERATE
         << "s to " << (stop*(double)FRAMESIZE)/(double)SAMPLERATE << "s\n";
    cout << "AvgEnergy (speech) = " << testavgE << "\n";
    cout << "AvgZCR (speech)   = " << finalZCR << "\n";
    cout << "HeadZCR           = " << headZ_cpf << "  TailZCR = " << tailZ_cpf << "\n";
    cout << "High-ZCR fraction = " << fracHigh << "\n";
    cout << "Avg Corr1 (voicing)= " << avgCorr1 << "\n";

    // final decision: YES or NO
    bool isYES = false;
    // YES: more noise at end or low correlation + high ZCR
    if ( (tailZ_cpf >= headZ_cpf * 1.10 && (tailZ_cpf - headZ_cpf) >= 3.0) ||
         (avgCorr1 < 0.45 && finalZCR >= 8.0) )
    {
        isYES = true;
    }
    // NO: very voiced and low ZCR
    if (avgCorr1 >= 0.60 && finalZCR < 15.0) {
        isYES = false;
    }

    if (isYES) cout << "Detected word: YES\n";
    else       cout << "Detected word: NO\n";

    delete[] AvgZCR; delete[] AvgEnergy; delete[] Corr1; delete[] samples;
    _getch();
    return 0;
}
