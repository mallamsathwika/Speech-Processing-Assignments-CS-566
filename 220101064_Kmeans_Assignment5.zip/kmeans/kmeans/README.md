# K-Means Clustering using Tokhura Distance

This project implements the K-Means clustering algorithm using Tokhura distance as the distance metric.  
The program clusters the input feature vectors into K = 8 clusters, each having 12 dimensions.  
After convergence, the final centroids are written to `Codebook.csv`.

---

## Files

- **kmeans.cpp** — Source code implementing K-Means clustering  
- **Universe.csv** — Input file containing all feature vectors (each line should have 12 comma-separated values)  
- **Codebook.csv** — Output file containing the final 8 centroid vectors generated after convergence

---

## Requirements

- Microsoft Visual Studio 2010 (or higher)
- C++ compiler with standard library support
- Input file `Universe.csv` placed in the same directory as the executable

---

## K-Means Step-by-Step Procedure

1. **Initialize Parameters**  
   - Set codebook size **K = 8**  
   - Set vector dimension **DIM = 12**  
   - Choose **delta (Δ)** for convergence (0.0001 used)

2. **Initialize Codebook**  
   - Set iteration counter **m = 0**  
   - Randomly select **K distinct vectors** from the universe to form the initial codebook  
   - Each vector has 12 values

3. **Assign Vectors to Nearest Centroid**  
   - For each vector in the universe, compute its Tokhura distance from each centroid  
   - Assign each vector to the cluster with the nearest centroid

4. **Compute Distortion**  
   - For all vectors, calculate the total distortion:  
     The sum of Tokhura distances between each vector and its assigned centroid  
   - Compute the average distortion:  
     **avg_dist = total_distortion / M**,  
     where **M** is the total number of vectors in the universe

5. **Update Codebook**  
   - For each cluster, compute the new centroid as the mean of all vectors in that cluster  
   - Replace old centroids with the new ones

6. **Check for Convergence**  
   - Increment iteration counter **m = m + 1**  
   - Repeat steps 3, 4, and 5 until  
     **|prevDistortion - currDistortion| ≤ Δ**  
   - When the change in distortion is less than delta, the algorithm stops

7. **Save Final Codebook**  
   - Write the final centroids (8 vectors × 12 values) to `Codebook.csv`

---

## How to Run in Visual Studio 2010

1. Open **Microsoft Visual Studio 2010**.  
2. Create a new **Win32 Console Application** project named `kmeans`.  
3. Add the existing source file **kmeans.cpp** to the project.  
4. Place **Universe.csv** in the same directory as the project’s executable.  
5. Build the project (`Ctrl + F7`).  
6. Run the program (`Ctrl + F5`).

After execution, the program will display:
- Selected initial centroids  
- Total and average distortion for each iteration  
- Total number of iterations  
- A message indicating successful completion  

The final codebook will be saved in `Codebook.csv` in the same directory.

---

## Output Description

- **Console Output:**  
  Displays initial centroids, total and average distortion for each iteration, and the number of iterations completed.  

- **Codebook.csv:**  
  Contains 8 final centroid vectors, each with 12 comma-separated values.

---

## Notes

- Ensure that `Universe.csv` contains valid data: each line should have exactly 12 numeric values separated by commas.  
- The convergence threshold (delta) can be adjusted in the source file if faster or more precise convergence is desired.
