#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

#define K 8             // Code book size
#define DIM 12          // Dimension for vector
#define DELTA 0.0001    // delta value for checking convergence 

double tokhuraWeights[DIM] = {1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};

// Function to read universe from CSV file
vector< vector<double> > readUniverse(string filename)
{
	vector< vector<double> > universe;
	ifstream file(filename.c_str());
	string line;

	while (getline(file, line))
	{
		stringstream ss(line);
		string value;
		vector<double> vec;
		while (getline(ss, value, ','))
		{
			vec.push_back(atof(value.c_str()));
		}
		if (vec.size() == DIM)
			universe.push_back(vec);
	}
	file.close();
	return universe;
}

// Function to calculate Tokhura distance
double tokhuraDistance(vector<double> a, vector<double> b)
{
	double dist = 0.0;
	for (int i = 0; i < DIM; i++)
	{
		double diff = a[i] - b[i];
		dist += tokhuraWeights[i] * diff * diff;
	}
	return dist;
}

// Compute centroid for each cluster
vector<double> computeCentroid(vector< vector<double> > cluster)
{
	vector<double> centroid(DIM, 0.0);
	if (cluster.size() == 0)
		return centroid;

	for (int i = 0; i < DIM; i++)
	{
		double sum = 0.0;
		for (int j = 0; j < (int)cluster.size(); j++)
			sum += cluster[j][i];
		centroid[i] = sum / cluster.size();
	}
	return centroid;
}

int _tmain(int argc, _TCHAR* argv[])
{
	srand((unsigned)time(0));

	vector< vector<double> > universe = readUniverse("Universe.csv");
	int M = (int)universe.size();

	if (M == 0)
	{
		cout << "Error: Universe.csv is empty or not found." << endl;
		return 0;
	}

	
	// Initialize codebook with K distinct random vectors
    vector<int> chosen;
	for (int i = 0; i < K; )
	{
		int index = rand() % M;
		bool already = false;
		for (int j = 0; j < (int)chosen.size(); j++)
		{
			if (chosen[j] == index)
			{
				already = true;
				break;
			}
		}
		if (!already)
		{
			chosen.push_back(index);
			i++;
		}
	}

	vector< vector<double> > codebook(K);
	for (int i = 0; i < K; i++)
		codebook[i] = universe[chosen[i]];

	// Print selected vectors (initial centroids) with indices
	cout << "\nSelected initial codebook vectors:\n";
	for (int i = 0; i < K; i++)
	{
		cout << "Vector " << i + 1 << " (Index " << chosen[i] + 1 << "): ";
		for (int j = 0; j < DIM; j++)
			cout << codebook[i][j] << " ";
		cout << endl;
	}
	cout << "---------------------------------------------" << endl;
	double prevDist = 9999999999.0; 
    double currDist = 0.0;
    int iteration = 0;
	while (true)
    {
         iteration++;
         vector<vector<vector<double>>> clusters(K);
         currDist = 0.0;
         
         // Assign each vector to the nearest centroid
         for (int i = 0; i < M; i++)
         {
              double minDist = 1e20;
              int nearest = 0;

           for (int j = 0; j < K; j++)
           {
               double dist = tokhuraDistance(universe[i], codebook[j]);
               if (dist < minDist)
               {
                  minDist = dist;
                  nearest = j;
               }
           }

           clusters[nearest].push_back(universe[i]);
           currDist += minDist; 
        }

       // Update centroids
       for (int i = 0; i < K; i++)
       {
            if (clusters[i].size() > 0)
            codebook[i] = computeCentroid(clusters[i]);
       }

       // Compute average distortion
       double avgDist = currDist / M;

      // Print total and average distortion
	  cout << fixed << setprecision(5);
      cout << "Iteration " << iteration << " - Total Distortion: " << currDist << ", Avg Distortion: " << avgDist << endl;

      // Check convergence using total distortion
      if (fabs(prevDist - currDist) <= DELTA)
          break;

       prevDist = currDist;
   }


	
	

	// Write final codebook to file
	ofstream out("Codebook.csv");
	for (int i = 0; i < K; i++)
	{
		for (int j = 0; j < DIM; j++)
		{
			out << codebook[i][j];
			if (j < DIM - 1) out << ",";
		}
		out << "\n";
	}
	out.close();

	cout << "---------------------------------------------" << endl;
	cout << "K-Means Completed " << endl;
	cout << "Final Codebook Saved as Codebook.csv" << endl;
	cout << "Total Iterations: " << iteration  << endl;

	return 0;
}
