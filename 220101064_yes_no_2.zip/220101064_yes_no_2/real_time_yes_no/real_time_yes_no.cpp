#include "stdafx.h"  
#include <windows.h>
#include <mmsystem.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <algorithm>
#pragma comment(lib, "winmm.lib")
using namespace std;

// Basic audio recording parameters
#define SAMPLE_RATE 16000      // Sampling rate: 16 kHz
#define BITS_PER_SAMPLE 16     // Bit depth
#define CHANNELS 1             // Mono audio
#define FRAME_MS 20            // Frame length: 20 ms
#define PREEMPH 0.97           // Pre-emphasis coefficient
#define AMPSCALE 5000.0        // Scale factor for amplitude
#define ZCR_EPS 5.0            // Threshold for zero crossing detection

// Structure to hold extracted features for each frame
struct FrameFeatures {
    double energy;             // Short-term energy
    double zcr;                // Zero Crossing Rate
    double correlation;        // Short-term correlation
    double spectralCentroid;   // Spectral centroid (approx.)
};

// Compute features from one frame of samples
FrameFeatures computeFrameFeatures(const short* buf, int start, int frameSize, double& prevSample) {
    FrameFeatures features = {0};
    double energy = 0.0, zcr = 0.0, num = 0.0, den = 0.0;
    double spectralSum = 0.0, weightedSum = 0.0;
    double prevEmph = 0.0;
    
    for (int i = 0; i < frameSize; i++) {
        // Apply pre-emphasis filter
        double sample = buf[start + i];
        double emphasized = sample - PREEMPH * prevSample;
        prevSample = sample;
        
        energy += emphasized * emphasized;
        
        // Zero Crossing Rate detection
        if (i > 0) {
            if ((emphasized > ZCR_EPS && prevEmph < -ZCR_EPS) || 
                (emphasized < -ZCR_EPS && prevEmph > ZCR_EPS)) {
                zcr += 1.0;
            }
            num += emphasized * prevEmph;
        }
        den += emphasized * emphasized;
        
        // Approximate spectral centroid
        double magnitude = abs(emphasized);
        spectralSum += magnitude;
        weightedSum += magnitude * (i + 1);
        
        prevEmph = emphasized;
    }
    
    features.energy = energy / frameSize;
    features.zcr = zcr / frameSize;
    features.correlation = (den > 1e-9) ? (num / den) : 0.0;
    features.spectralCentroid = (spectralSum > 0) ? (weightedSum / spectralSum) : 0.0;
    
    return features;
}

// Holds adaptive thresholds estimated from background noise
struct AdaptiveThresholds {
    double energyThresholdLow;
    double energyThresholdHigh;
    double zcrThreshold;
    double noiseEnergy;
    double noiseZcr;
};

// Estimate thresholds from initial noise frames
AdaptiveThresholds estimateThresholds(const vector<FrameFeatures>& features, int noiseFrames) {
    AdaptiveThresholds thresholds = {0};
    
    if (noiseFrames > features.size()) noiseFrames = features.size();
    if (noiseFrames == 0) return thresholds;
    
    // Average noise energy & ZCR
    for (int i = 0; i < noiseFrames; i++) {
        thresholds.noiseEnergy += features[i].energy;
        thresholds.noiseZcr += features[i].zcr;
    }
    thresholds.noiseEnergy /= noiseFrames;
    thresholds.noiseZcr /= noiseFrames;
    
    // Set thresholds relative to noise floor
    thresholds.energyThresholdLow = thresholds.noiseEnergy * 4.0;
    thresholds.energyThresholdHigh = thresholds.noiseEnergy * 8.0;
    thresholds.zcrThreshold = thresholds.noiseZcr * 1.2;
    
    return thresholds;
}

// Detect speech boundaries using hysteresis
pair<int, int> detectSpeech(const vector<FrameFeatures>& features, const AdaptiveThresholds& thresh) {
    int start = -1, end = -1;
    bool inSpeech = false;
    int lowEnergyCount = 0;
    int minSpeechFrames = 8;   // Minimum duration ~160 ms
    int maxSilenceFrames = 5;  // Max silence gap ~100 ms
    
    for (int i = 0; i < features.size(); i++) {
        if (!inSpeech) {
            // Detect speech onset
            if (features[i].energy > thresh.energyThresholdHigh) {
                start = i;
                inSpeech = true;
                lowEnergyCount = 0;
            }
        } else {
            // Detect speech offset
            if (features[i].energy < thresh.energyThresholdLow) {
                lowEnergyCount++;
                if (lowEnergyCount >= maxSilenceFrames) {
                    end = i - lowEnergyCount;
                    break;
                }
            } else {
                lowEnergyCount = 0;
            }
        }
    }
    
    if (inSpeech && end == -1) {
        end = features.size() - 1;
    }
    
    // Reject too short segments
    if (start >= 0 && end >= 0 && (end - start + 1) >= minSpeechFrames) {
        return make_pair(start, end);
    }
    
    return make_pair(-1, -1);
}

// Classify detected speech as YES, NO, or SILENCE
string classifyWord(const vector<FrameFeatures>& features, int start, int end, 
                   const AdaptiveThresholds& thresh) {
    if (start < 0 || end < 0 || start > end) return "SILENCE";
    
    int speechFrames = end - start + 1;
    double avgEnergy = 0, avgZcr = 0, avgCorr = 0, avgSpectral = 0;
    
    // Average features across speech
    for (int i = start; i <= end; i++) {
        avgEnergy += features[i].energy;
        avgZcr += features[i].zcr;
        avgCorr += features[i].correlation;
        avgSpectral += features[i].spectralCentroid;
    }
    avgEnergy /= speechFrames;
    avgZcr /= speechFrames;
    avgCorr /= speechFrames;
    avgSpectral /= speechFrames;
    
    // Analyze onset, middle, and offset frames
    int transitionFrames = min(speechFrames / 5, 6);
    int midStart = start + speechFrames / 3;
    int midEnd = start + (2 * speechFrames) / 3;
    
    double onsetZcr = 0, offsetZcr = 0, midZcr = 0;
    double onsetCorr = 0, offsetCorr = 0, midCorr = 0;
    double onsetEnergy = 0, offsetEnergy = 0, midEnergy = 0;
    
    // Onset stats
    for (int i = 0; i < transitionFrames && (start + i) < features.size(); i++) {
        onsetZcr += features[start + i].zcr;
        onsetCorr += features[start + i].correlation;
        onsetEnergy += features[start + i].energy;
    }
    onsetZcr /= transitionFrames;
    onsetCorr /= transitionFrames;
    onsetEnergy /= transitionFrames;
    
    // Offset stats
    for (int i = 0; i < transitionFrames && (end - i) >= 0; i++) {
        offsetZcr += features[end - i].zcr;
        offsetCorr += features[end - i].correlation;
        offsetEnergy += features[end - i].energy;
    }
    offsetZcr /= transitionFrames;
    offsetCorr /= transitionFrames;
    offsetEnergy /= transitionFrames;
    
    // Middle stats
    int midFrames = 0;
    for (int i = midStart; i <= midEnd && i < features.size(); i++) {
        midZcr += features[i].zcr;
        midCorr += features[i].correlation;
        midEnergy += features[i].energy;
        midFrames++;
    }
    if (midFrames > 0) {
        midZcr /= midFrames;
        midCorr /= midFrames;
        midEnergy /= midFrames;
    }
    
    // Convert ZCR into crossings per frame
    double zcrPerFrame = avgZcr * SAMPLE_RATE * FRAME_MS / 1000;
    double onsetZcrPerFrame = onsetZcr * SAMPLE_RATE * FRAME_MS / 1000;
    double offsetZcrPerFrame = offsetZcr * SAMPLE_RATE * FRAME_MS / 1000;
    double midZcrPerFrame = midZcr * SAMPLE_RATE * FRAME_MS / 1000;
    
    // Basic duration and energy checks
    double duration = speechFrames * FRAME_MS / 1000.0;
    if (duration < 0.15 || duration > 3.0) return "SILENCE";
    
    double energyRatio = avgEnergy / max(thresh.noiseEnergy, 1.0);
    if (energyRatio < 6.0) return "SILENCE";
    
    // Energy variation across speech
    double energyVariation = (abs(onsetEnergy - midEnergy) + abs(midEnergy - offsetEnergy)) / avgEnergy;
    
    cout << "  Detailed analysis:" << endl;
    cout << "    Onset ZCR: " << onsetZcrPerFrame << ", Mid ZCR: " << midZcrPerFrame << ", Offset ZCR: " << offsetZcrPerFrame << endl;
    cout << "    Onset Corr: " << onsetCorr << ", Mid Corr: " << midCorr << ", Offset Corr: " << offsetCorr << endl;
    cout << "    Energy variation: " << energyVariation << endl;
    
    // Classification rules (YES / NO based on patterns)
    if (energyRatio > 275.0) return "YES";
    
    if (energyRatio > 80.0 && energyRatio < 700.0) {
        if (midCorr < 0.25 && energyVariation > 1.5) return "YES";
        if (midZcrPerFrame > onsetZcrPerFrame * 1.5 && midCorr < 0.30) return "YES";
        return "NO";
    }
    
    if (energyRatio < 50.0) return "SILENCE";
    
    if (midCorr < 0.30 && energyVariation > 1.0) return "YES";
    if (midZcrPerFrame > onsetZcrPerFrame * 1.3 && midCorr < 0.35) return "YES";
    if (midCorr > 0.40 && offsetCorr > 0.35 && energyVariation < 0.6) return "NO";
    if (energyVariation > 1.2 && avgCorr < 0.40) return "YES";
    
    return (avgCorr > 0.45 && energyVariation < 0.5) ? "NO" : "YES";
}

int main() {
    HWAVEIN hWaveIn;
    WAVEFORMATEX wfx;
    WAVEHDR header;
    vector<short> buffer(SAMPLE_RATE * 3); // Record 3 seconds of audio

    // Configure PCM format
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = CHANNELS;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = BITS_PER_SAMPLE;
    wfx.nBlockAlign = (wfx.wBitsPerSample / 8) * wfx.nChannels;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;
    wfx.cbSize = 0;

    // Open microphone
    if (waveInOpen(&hWaveIn, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        cout << "Error opening input device." << endl;
        return -1;
    }

    // Prepare buffer
    header.lpData = (LPSTR)buffer.data();
    header.dwBufferLength = buffer.size() * sizeof(short);
    header.dwFlags = 0;
    header.dwLoops = 0;

    waveInPrepareHeader(hWaveIn, &header, sizeof(WAVEHDR));
    waveInAddBuffer(hWaveIn, &header, sizeof(WAVEHDR));

    // Record 3 seconds
    cout << "Recording for 3 seconds..." << endl;
    waveInStart(hWaveIn);
    Sleep(3000);
    waveInStop(hWaveIn);
    waveInUnprepareHeader(hWaveIn, &header, sizeof(WAVEHDR));
    waveInClose(hWaveIn);
    cout << "Recording complete." << endl;

    // Frame-level feature extraction
    int frameSize = SAMPLE_RATE * FRAME_MS / 1000;
    int numFrames = buffer.size() / frameSize;
    
    vector<FrameFeatures> features;
    double prevSample = 0.0;
    
    for (int f = 0; f < numFrames; f++) {
        int start = f * frameSize;
        FrameFeatures frameFeats = computeFrameFeatures(buffer.data(), start, frameSize, prevSample);
        features.push_back(frameFeats);
    }

    // Estimate thresholds from noise
    int noiseFrames = min(15, numFrames / 3); // First 300ms or 1/3rd of recording
    AdaptiveThresholds thresholds = estimateThresholds(features, noiseFrames);
    
    cout << "Noise floor - Energy: " << thresholds.noiseEnergy 
         << ", ZCR: " << thresholds.noiseZcr << endl;
    cout << "Thresholds - Energy Low: " << thresholds.energyThresholdLow
         << ", High: " << thresholds.energyThresholdHigh << endl;

    // Detect speech region
    pair<int, int> speechSegment = detectSpeech(features, thresholds);
    
    if (speechSegment.first < 0) {
        cout << "Detected word: SILENCE" << endl;
        return 0;
    }
    
    // Report timing
    double startTime = speechSegment.first * frameSize / (double)SAMPLE_RATE;
    double endTime = speechSegment.second * frameSize / (double)SAMPLE_RATE;
    cout << "Speech detected from " << startTime << "s to " << endTime << "s" << endl;
    
    // Classify speech
    string result = classifyWord(features, speechSegment.first, speechSegment.second, thresholds);
    
    // Show average features
    int start = speechSegment.first, end = speechSegment.second;
    int speechFrames = end - start + 1;
    double avgE = 0, avgZ = 0, avgC = 0;
    for (int i = start; i <= end; i++) {
        avgE += features[i].energy;
        avgZ += features[i].zcr;
        avgC += features[i].correlation;
    }
    avgE /= speechFrames;
    avgZ /= speechFrames; 
    avgC /= speechFrames;
    
    cout << "Speech features:" << endl;
    cout << "  Average Energy: " << avgE << " (ratio: " << avgE/thresholds.noiseEnergy << ")" << endl;
    cout << "  Average ZCR: " << avgZ * frameSize << " crossings/frame" << endl;
    cout << "  Average Correlation: " << avgC << endl;
    cout << "  Duration: " << (endTime - startTime) << "s" << endl;

    cout << "Detected word: " << result << endl;
    return 0;
}
