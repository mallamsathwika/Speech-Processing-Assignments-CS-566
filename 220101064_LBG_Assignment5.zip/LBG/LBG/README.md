# Linde–Buzo–Gray (LBG) Algorithm using Tokhura Distance

This project implements the **Linde–Buzo–Gray (LBG)** vector quantization algorithm using **Tokhura distance** as the distortion metric.  
The algorithm generates a **codebook** of representative vectors (centroids) by iteratively splitting and refining clusters.  
Each vector has 12 dimensions, and the final codebook contains **K = 8** codewords.

---

## Files

- **LBG.cpp** — Source code implementing the LBG algorithm  
- **Universe.csv** — Input file containing the universe of feature vectors (each line has 12 comma-separated values)  
- **Codebook.csv** — Output file containing the final 8 centroid vectors after convergence  

---

## Requirements

- Microsoft Visual Studio 2010 (or higher)  
- C++ compiler with standard library support  
- Input file **Universe.csv** must be in the same directory as the executable  

---

## LBG Step-by-Step Procedure

1. **Initialize Parameters**  
   - Codebook size **K = 8**  
   - Vector dimension **DIM = 12**  
   - Splitting factor **ε = 0.03**  
   - Convergence threshold **Δ = 0.0001**

2. **Start with One Vector**  
   - Compute the centroid of the entire universe (mean of all vectors).  
   - This single vector represents the initial codebook with one entry.

3. **Splitting Step**  
   - For each vector `Yi` in the current codebook, generate two new vectors:  
     - `Yi+ = Yi × (1 + ε)`  
     - `Yi− = Yi × (1 - ε)`  
   - After splitting, the codebook size doubles.

4. **Refinement (K-Means Stage)**  
   - Assign each universe vector to the nearest centroid using the **Tokhura distance**.  
   - Recompute centroids for each cluster.  
   - Calculate total and average distortion.  
   - Repeat until convergence (when the change in distortion ≤ Δ).

5. **Repeat**  
   - Continue splitting and refining until the codebook size reaches **K = 8**.

6. **Save Final Codebook**  
   - Write the final 8 codewords (each with 12 values) to `Codebook.csv`.

---

## How to Run in Visual Studio 2010

1. Open **Microsoft Visual Studio 2010**.  
2. Create a new **Win32 Console Application** project named `LBG`.  
3. Add the existing source file **LBG.cpp** to the project.  
4. Place **Universe.csv** in the same directory as the project’s executable.  
5. Build the project (`Ctrl + F7`).  
6. Run the program (`Ctrl + F5`).

---

## Program Output

- **Console Output:**  
  - Displays the centroid at each splitting stage.  
  - Shows total and average distortion for every K-Means iteration.  
  - Prints the refined codebook after each split until the final codebook size is reached.

- **Codebook.csv:**  
  - Contains the final 8 centroid vectors (12 comma-separated values per line).  


---

## Notes

- Ensure that `Universe.csv` has exactly **12 comma-separated numeric values per line**.  
- The parameters `K`, `EPSILON`, and `DELTA` can be adjusted in `LBG.cpp` for different codebook sizes or precision levels.  
- The algorithm stops automatically when distortion between iterations changes less than Δ.

