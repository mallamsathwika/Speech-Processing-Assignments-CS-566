#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

#define DIM 12              // Dimension of each vector
#define K 8                 // Final codebook size
#define EPSILON 0.03        // Splitting factor
#define DELTA 0.0001        // Convergence threshold

double tokhuraWeights[DIM] = {1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};

// Function to read universe from CSV file
vector<vector<double>> readUniverse(string filename) {
    vector<vector<double>> universe;
    ifstream file(filename.c_str());
    string line;

    while (getline(file, line)) {
        stringstream ss(line);
        string value;
        vector<double> vec;
        while (getline(ss, value, ',')) {
            vec.push_back(atof(value.c_str()));
        }
        if (vec.size() == DIM)
            universe.push_back(vec);
    }
    file.close();
    return universe;
}

// Compute Tokhura distance between two vectors
double tokhuraDistance(const vector<double>& a, const vector<double>& b) {
    double dist = 0.0;
    for (int i = 0; i < DIM; i++) {
        double diff = a[i] - b[i];
        dist += tokhuraWeights[i] * diff * diff;
    }
    return dist;
}

// Compute centroid of a cluster
vector<double> computeCentroid(const vector<vector<double>>& cluster) {
    vector<double> centroid(DIM, 0.0);
    if (cluster.empty()) return centroid;

    for (int i = 0; i < DIM; i++) {
        double sum = 0.0;
        for (int j = 0; j < (int)cluster.size(); j++)
            sum += cluster[j][i];
        centroid[i] = sum / cluster.size();
    }
    return centroid;
}

// Perform K-Means refinement for given codebook
void refineCodebook(vector<vector<double>>& codebook, const vector<vector<double>>& universe) {
    int size = (int)codebook.size();
    double prevDist = 1e20;
    double currDist = 0.0;
    int iteration = 0;

    while (true) {
        iteration++;
        vector<vector<vector<double>>> clusters(size);
        currDist = 0.0;

        // Assign each vector to the nearest centroid
        for (int i = 0; i < (int)universe.size(); i++) {
            double minDist = 1e20;
            int nearest = 0;
            for (int j = 0; j < size; j++) {
                double dist = tokhuraDistance(universe[i], codebook[j]);
                if (dist < minDist) {
                    minDist = dist;
                    nearest = j;
                }
            }
            clusters[nearest].push_back(universe[i]);
            currDist += minDist;
        }

        // Update centroids
        for (int j = 0; j < size; j++) {
            if (!clusters[j].empty())
                codebook[j] = computeCentroid(clusters[j]);
        }

        double avgDist = currDist / universe.size();
        cout << "Iteration " << iteration << " | Total Distortion: " << fixed << setprecision(6) << currDist << " | Avg Distortion: " << avgDist << endl;

        if (fabs(prevDist - currDist) < DELTA)
            break;

        prevDist = currDist;
    }

    // Print refined codebook
    cout << "\nRefined Codebook (" << size << " vectors):\n";
    for (int i = 0; i < size; i++) {
        cout << "Vector " << i + 1 << ": ";
        for (int j = 0; j < DIM; j++)
            cout << fixed << setprecision(6) << codebook[i][j] << " ";
        cout << endl;
    }
    cout << "---------------------------------------------" << endl;
}

int _tmain(int argc, _TCHAR* argv[]) {
    srand((unsigned)time(0));

    vector<vector<double>> universe = readUniverse("Universe.csv");
    if (universe.empty()) {
        cout << "Error: Universe.csv not found or empty." << endl;
        return 0;
    }

    cout << "Universe size: " << universe.size() << endl;
    cout << "---------------------------------------------" << endl;

    // Start with a single centroid (mean of all vectors)
    vector<double> centroid = computeCentroid(universe);
    vector<vector<double>> codebook;
    codebook.push_back(centroid);

    cout << "Initial centroid created.\n";
    for (int i = 0; i < DIM; i++)
        cout << centroid[i] << " ";
    cout << "\n---------------------------------------------" << endl;

    // Split and refine until codebook size = K
    while ((int)codebook.size() < K) {
        vector<vector<double>> newCodebook;
        for (int i = 0; i < (int)codebook.size(); i++) {
            vector<double> yPlus(DIM), yMinus(DIM);
            for (int j = 0; j < DIM; j++) {
                yPlus[j]  = codebook[i][j] * (1 + EPSILON);
                yMinus[j] = codebook[i][j] * (1 - EPSILON);
            }
            newCodebook.push_back(yPlus);
            newCodebook.push_back(yMinus);
        }
        codebook = newCodebook;

        cout << "Codebook split to size " << codebook.size() << endl;
        refineCodebook(codebook, universe);
    }

    // Save final codebook
    ofstream out("Codebook.csv");
    for (int i = 0; i < (int)codebook.size(); i++) {
        for (int j = 0; j < DIM; j++) {
            out << codebook[i][j];
            if (j < DIM - 1) out << ",";
        }
        out << "\n";
    }
    out.close();

    cout << "Final Codebook saved as Codebook.csv" << endl;
    cout << "---------------------------------------------" << endl;
    return 0;
}
