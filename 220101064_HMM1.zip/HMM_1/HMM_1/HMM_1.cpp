﻿#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <cmath>    
using namespace std;

// Function to split a line into doubles
vector<double> splitToDouble(const string &line)
{
    stringstream ss(line);
    vector<double> res;
    double val;
    while (ss >> val)
        res.push_back(val);
    return res;
}

int main()
{
    ifstream modelFile("Initial_Model.txt");
    ifstream obsFile("HMM_OBSERVATION_SEQUENCE_1.txt");
    if (!modelFile.is_open() || !obsFile.is_open())
    {
        cerr << "Error: Could not open input files." << endl;
        return 1;
    }

    vector<vector<double> > A, B;
    vector<double> PI;
    string line;
    bool readA = false, readB = false, readPI = false;

    //  Read A, B, and PI matrices
    while (getline(modelFile, line))
    {
        if (line.find("A Matrix") != string::npos)
        {
            readA = true; readB = readPI = false; continue;
        }
        if (line.find("B Matrix") != string::npos)
        {
            readB = true; readA = readPI = false; continue;
        }
        if (line.find("PI Matrix") != string::npos)
        {
            readPI = true; readA = readB = false; continue;
        }
        if (line.empty()) continue;

        if (readA)
            A.push_back(splitToDouble(line));
        else if (readB)
            B.push_back(splitToDouble(line));
        else if (readPI)
            PI = splitToDouble(line);
    }

    //Read observation sequence
    vector<int> O;
    while (getline(obsFile, line))
    {
        stringstream ss(line);
        int obs;
        while (ss >> obs)
            O.push_back(obs - 1); // zero-based indexing
    }

    int N = (int)A.size();       // number of states
    int M = (int)B[0].size();    // number of observation symbols
    int T = (int)O.size();       // length of observation sequence

    vector<vector<double> > alpha(N, vector<double>(T, 0.0));
    vector<double> c(T, 0.0);    // scaling coefficients

    //  Initialization
    for (int i = 0; i < N; i++)
    {
        alpha[i][0] = PI[i] * B[i][O[0]];
        c[0] += alpha[i][0];
    }

    // Scale alpha[ ][0]
    if (c[0] != 0.0) c[0] = 1.0 / c[0];
    for (int i = 0; i < N; i++)
        alpha[i][0] *= c[0];

    //  Induction 
    for (int t = 1; t < T; t++)
    {
        for (int j = 0; j < N; j++)
        {
            double sum = 0.0;
            for (int i = 0; i < N; i++)
                sum += alpha[i][t - 1] * A[i][j];
            alpha[j][t] = sum * B[j][O[t]];
        }

        c[t] = 0.0;
        for (int i = 0; i < N; i++)
            c[t] += alpha[i][t];

        if (c[t] != 0.0) c[t] = 1.0 / c[t];
        for (int i = 0; i < N; i++)
            alpha[i][t] *= c[t];
    }

    //Termination 
    double logProb = 0.0;
    for (int t = 0; t < T; t++)
        logProb += log(1.0 / c[t]);  
    cout.setf(ios::fixed);
    cout << setprecision(10);
    cout << "Log Probability of the observation sequence given the model = "
         << logProb << endl;
	double prob = exp(logProb);
    cout << "Probability of the observation sequence given the model = "
     << scientific << setprecision(11) << prob << endl;

    modelFile.close();
    obsFile.close();
    return 0;
}
