# Hidden Markov Model – Problem 1 (Evaluation using Forward Algorithm with Scaling)

This assignment implements **Hidden Markov Model (HMM) Problem 1 – the Evaluation Problem**,  
which calculates the probability of an observation sequence **P(O | λ)** given a model  
**λ = (A, B, π)**.

Because repeated multiplications of small probabilities lead to **floating-point underflow**,  
the program uses the **Scaled Forward Algorithm**.  
It prints both the **log probability** (numerically stable) and the **actual probability**  
in scientific notation.

---

## Files

- **HMM_1.cpp** — Source code implementing the scaled Forward Algorithm  
- **Initial_Model.txt** — Input file containing the transition matrix (A), observation matrix (B), and initial probabilities (π)  
- **HMM_OBSERVATION_SEQUENCE_1.txt** — Input file containing the observation sequence  
- **Console Output:**  
  - Log probability of the observation sequence  
  - Probability of the observation sequence (scientific notation)

---

## Algorithm Overview

### 1. Initialization
For each state `i`:
\[
\alpha_1(i) = \pi_i \times b_i(O_1)
\]

Compute scaling coefficient:
\[
c_1 = \frac{1}{\sum_i \alpha_1(i)}
\]

Scale the values:
\[
\hat{\alpha}_1(i) = c_1 \times \alpha_1(i)
\]

---

### 2. Induction
For each time step `t = 2 … T` and each state `j`:
\[
\alpha_t(j) = \Big(\sum_i \hat{\alpha}_{t-1}(i) \times a_{ij}\Big) \times b_j(O_t)
\]

Compute scaling constant:
\[
c_t = \frac{1}{\sum_j \alpha_t(j)}
\]

Scale the results:
\[
\hat{\alpha}_t(j) = c_t \times \alpha_t(j)
\]

---

### 3. Termination
After processing all observations:
\[
P(O|\lambda) = \frac{1}{c_1 c_2 \dots c_T}
\]
and in log form:
\[
\log P(O|\lambda) = -\sum_{t=1}^{T} \log c_t
\]

The program prints both values:
Log Probability of the observation sequence given the model = -294.5875517380
Probability of the observation sequence given the model = 1.15412232722e-128


---

## How Log Probability Is Calculated

Since direct multiplication of probabilities causes underflow (values → 0.0),  
we use scaling factors **cₜ** at each time step.  

Each α-vector is normalized using **cₜ**, and at the end we reconstruct the actual  
log-probability as:

\[
\text{logProb} = \sum_t \log\!\left(\frac{1}{c_t}\right)
\]

This approach is numerically stable even for long sequences.

---

## How to Run in Visual Studio 2010

1. Open **Microsoft Visual Studio 2010**  
2. Create a new **Win32 Console Application** project named `HMM_1`  
3. Add the existing source file **HMM_1_scaled.cpp** to the project  
4. Place both input files (`Initial_Model.txt`, `HMM_OBSERVATION_SEQUENCE_1.txt`) in the same directory as the executable (e.g., the `Debug` folder)  
5. Build the project (`Ctrl + F7`)  
6. Run the program (`Ctrl + F5`)


---

## Example Output
Log Probability of the observation sequence given the model = -294.5875517380
Probability of the observation sequence given the model = 1.15412232722e-128


---

## Notes

- The **log probability** is the correct and stable representation of **P(O|λ)**  
- The raw probability is displayed in scientific notation for clarity  
- Scaling ensures numerical stability during forward computation  
- Input files must follow the same structure as the provided `Initial_Model.txt` and `HMM_OBSERVATION_SEQUENCE_1.txt`


