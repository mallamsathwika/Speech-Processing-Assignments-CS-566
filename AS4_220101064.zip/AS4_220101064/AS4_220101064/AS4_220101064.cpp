#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <string>
#include <iomanip>
#include <algorithm>
#include <sstream>

using namespace std;

#define FRAME_SIZE 320
#define LPC_ORDER 12
#define PI 3.141593

// Reading Signal from input file
vector<double> readSignal(const string& filename) {
    ifstream fin(filename.c_str());
    vector<double> signal;
    double x;
    while (fin >> x) signal.push_back(x);
    return signal;
}

// DC shift removal + normalization
void dcShiftAndNormalize(vector<double>& signal) {
    if (signal.empty()) return;

	// Compute mean (DC offset)
    double mean = 0.0;
    for (size_t i = 0; i < signal.size(); i++) mean += signal[i];
    mean /= signal.size();

	// Subtract mean
    for (size_t i = 0; i < signal.size(); i++) signal[i] -= mean;

	// Find maximum absolute value
    double maxVal = 0.0;
    for (size_t i = 0; i < signal.size(); i++)
        if (fabs(signal[i]) > maxVal) maxVal = fabs(signal[i]);

	// Normalize
    if (maxVal > 0) {
        for (size_t i = 0; i < signal.size(); i++) signal[i] /= maxVal;
    }
}

// Split input samples into frames
vector<vector<double>> splitFrames(const vector<double>& signal) {
    vector<vector<double>> frames;
    int totalFrames = (int)(signal.size() / FRAME_SIZE);
    for (int i = 0; i < totalFrames; i++) {
        vector<double> frame(signal.begin() + i * FRAME_SIZE,
                             signal.begin() + (i + 1) * FRAME_SIZE);
        frames.push_back(frame);
    }
    return frames;
}

// Compute energy of each frame
vector<double> frameEnergy(const vector<vector<double>>& frames) {
    vector<double> energy;
    for (size_t i = 0; i < frames.size(); i++) {
        double E = 0.0;
        for (size_t j = 0; j < frames[i].size(); j++) {
            E += frames[i][j] * frames[i][j];
        }
        energy.push_back(E);
    }
    return energy;
}

// Apply Hamming window
void applyHamming(vector<double>& frame) {
    int N = (int)frame.size();
    for (int n = 0; n < N; n++) {
        double w = 0.54 - 0.46 * cos((2.0 * PI * n) / (N - 1));
        frame[n] *= w;
    }
}

// Auto Correlation calculation
vector<double> autocorrelation(const vector<double>& frame, int p) {
    vector<double> R(p + 1, 0.0);
    int N = (int)frame.size();
    for (int k = 0; k <= p; k++) {
        for (int n = 0; n < N - k; n++) {
            R[k] += frame[n] * frame[n + k];
        }
    }
    return R;
}

// Levinson-Durbin recursion to compute LPC coefficients
vector<double> levinsonDurbin(const vector<double>& R, int p) {
    vector<double> a(p + 1, 0.0), E(p + 1, 0.0);
    a[0] = 1.0;
    if (R.empty()) return vector<double>(p, 0.0);
    E[0] = R[0];

    for (int i = 1; i <= p; i++) {
		// Reflection coefficient
        double acc = 0.0;
        for (int j = 1; j < i; j++) acc += a[j] * R[i - j];
        double k = (E[i - 1] != 0.0) ? (R[i] - acc) / E[i - 1] : 0.0;

		// Update coefficients
        vector<double> a_new = a;
        for (int j = 1; j < i; j++) a_new[j] = a[j] - k * a[i - j];
        a_new[i] = k;
        a = a_new;

		// Update error
        E[i] = (1 - k * k) * E[i - 1];
    }

    vector<double> coeffs;
    for (int i = 1; i <= p; i++) coeffs.push_back(a[i]);
    return coeffs;
}

//  Cepstrum 
vector<double> computeCepstral(const vector<double>& A, const vector<double>& R, int p) {
    vector<double> C(p + 1, 0.0);
    if (R.size() > 0 && R[0] > 0.0) C[0] = log(R[0]);
    else C[0] = 0.0;

    for (int m = 1; m <= p; m++) {
        double sum = 0.0;
        for (int k = 1; k < m; k++) {
            if (k < (int)C.size() && (m - k - 1) >= 0 && (m - k - 1) < (int)A.size())
                sum += ((double)k / (double)m) * C[k] * A[m - k - 1];
        }
        if ((m - 1) < (int)A.size()) C[m] = A[m - 1] + sum;
    }
    if (!C.empty()) C.erase(C.begin());
    return C;
}

// Apply raised sine window
void applyRaisedSine(vector<double>& C) {
    int Q = (int)C.size();
    for (int m = 1; m <= Q; m++) {
        double w = 1.0 + (Q / 2.0) * sin((PI * m) / Q);
        C[m - 1] *= w;
    }
}

// Frame selection  
vector<int> selectFramesWithThreshold(const vector<double>& energies) {
    int totalFrames = (int)energies.size();
    vector<int> selected;
    if (totalFrames <= 0) return selected;

    int take = min(5, totalFrames);
    double silenceEnergy = 0.0;
    int count = 0;

	// estimate silence energy using first & last few frames
    for (int i = 0; i < take; i++) {
        silenceEnergy += energies[i];                         // first few frames
        silenceEnergy += energies[totalFrames - 1 - i];       // last few frames
        count += 2;
    }
    if (count == 0) count = 1;
    double threshold = (silenceEnergy / count) * 2.0;  // set threshold higher
	
	// pick 5 frames around the middle
    int mid = totalFrames / 2;
    for (int i = -2; i <= 2; i++) {
        int idx = mid + i;
        if (idx >= 0 && idx < totalFrames && energies[idx] > threshold) {
            selected.push_back(idx);
        }
    }

	// if less than 5 selected, pad with neighbors
    if ((int)selected.size() < 5) {
        for (int i = -2; i <= 2 && (int)selected.size() < 5; i++) {
            int idx = mid + i;
            if (idx >= 0 && idx < totalFrames) {
                if (find(selected.begin(), selected.end(), idx) == selected.end()) {
                    selected.push_back(idx);
                }
            }
        }
    }
    if ((int)selected.size() > 5) selected.resize(5);
    sort(selected.begin(), selected.end());
    return selected;
}

// Helper 
string replaceExtension(const string& filename, const string& suffix) {
    size_t pos = filename.find_last_of('.');
    if (pos == string::npos) return filename + suffix;
    return filename.substr(0, pos) + suffix;
}

// Read reference file 
bool readReferenceFile(const string& filename, vector<vector<double>>& outRows) {
    ifstream fin(filename.c_str());
    if (!fin) return false;
    outRows.clear();
    for (int r = 0; r < 5; r++) {
        vector<double> row(LPC_ORDER);
        for (int c = 0; c < LPC_ORDER; c++) {
            if (!(fin >> row[c])) return false;
        }
        outRows.push_back(row);
    }
    return true;
}

// Tokhura weights
const double TOKHURA_WEIGHTS[LPC_ORDER] = {
    1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0
};

// Compute Tokhura distance between two LPC-cepstral vectors 
double tokhuraDistance(const vector<double>& v1, const vector<double>& v2) {
    double sum = 0.0;
    for (int k = 0; k < LPC_ORDER; k++) {
        double diff = v1[k] - v2[k];
        sum += TOKHURA_WEIGHTS[k] * diff * diff;
    }
    return sum;
}

// Process a single audio file and compute Ci for selected frames
vector<vector<double>> computeCiForTestFile(const string& audioFilename) {
    vector<double> signal = readSignal(audioFilename);
    if (signal.empty()) return vector<vector<double>>();

    dcShiftAndNormalize(signal);
    vector<vector<double>> frames = splitFrames(signal);
    if (frames.empty()) return vector<vector<double>>();

    vector<double> energies = frameEnergy(frames);
    vector<int> selected = selectFramesWithThreshold(energies);

    // Ensure exactly 5 frames
    if ((int)selected.size() < 5) {
        // pad using neighboring frames if necessary
        int mid = (int)frames.size() / 2;
        for (int offset = 0; (int)selected.size() < 5 && offset <= mid; offset++) {
            int cand1 = mid - offset;
            int cand2 = mid + offset;
            if (cand1 >= 0 && find(selected.begin(), selected.end(), cand1) == selected.end())
                selected.push_back(cand1);
            if ((int)selected.size() < 5 && cand2 < (int)frames.size() && find(selected.begin(), selected.end(), cand2) == selected.end())
                selected.push_back(cand2);
        }
    }
    if ((int)selected.size() > 5) selected.resize(5);
    sort(selected.begin(), selected.end());

    vector<vector<double>> CiFrames;
    for (size_t idx = 0; idx < selected.size(); idx++) {
        int fidx = selected[idx];
        vector<double> frame = frames[fidx];
        applyHamming(frame);
        vector<double> R = autocorrelation(frame, LPC_ORDER);
        vector<double> A = levinsonDurbin(R, LPC_ORDER);
        vector<double> C = computeCepstral(A, R, LPC_ORDER);
        applyRaisedSine(C);

        // Ensure C has LPC_ORDER elements
        if ((int)C.size() < LPC_ORDER) C.resize(LPC_ORDER, 0.0);
        CiFrames.push_back(C);
    }

    
    while ((int)CiFrames.size() < 5) CiFrames.push_back(vector<double>(LPC_ORDER, 0.0));
    return CiFrames;
}

// Infer expected vowel from basename like "220101064_a"
char inferExpectedVowel(const string& basename) {
    // look for underscore, vowel, underscore pattern
    for (size_t i = 0; i + 2 < basename.size(); i++) {
        if (basename[i] == '_') {
            char c = tolower(basename[i + 1]);
            if ((basename[i + 2] == '_') && (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u'))
                return c;
        }
    }
    // search for any vowel char in basename
    for (size_t i = 0; i < basename.size(); i++) {
        char c = tolower(basename[i]);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') return c;
    }
    return '?';
}

int main() {
    int mode;
    cout << "Enter mode (1=single recording, 2=average, 3=recognition test): ";
    cin >> mode;

    if (mode == 1) {

		// Mode 1: extract Ci from one recording
        string inFile;
        cout << "Enter input file name with extension: ";
        cin >> inFile;

        string outFile = replaceExtension(inFile, "_ci.txt");

        vector<double> signal = readSignal(inFile);
        if (signal.empty()) {
            cerr << "Error reading " << inFile << "\n";
            return 1;
        }
        dcShiftAndNormalize(signal);
        vector<vector<double>> frames = splitFrames(signal);
        if (frames.empty()) {
            cerr << "No frames in " << inFile << "\n";
            return 1;
        }
        vector<double> energy = frameEnergy(frames);
        vector<int> selected = selectFramesWithThreshold(energy);

        ofstream fout(outFile.c_str());
        fout << fixed << setprecision(6);
        for (size_t i = 0; i < selected.size(); i++) {
            int idx = selected[i];
            if (idx >= 0 && idx < (int)frames.size()) {
                vector<double> frame = frames[idx];
                applyHamming(frame);
                vector<double> R = autocorrelation(frame, LPC_ORDER);
                vector<double> A = levinsonDurbin(R, LPC_ORDER);
                vector<double> C = computeCepstral(A, R, LPC_ORDER);
                applyRaisedSine(C);

                for (size_t j = 0; j < C.size(); j++) fout << C[j] << "\t";
                fout << "\n";
            }
        }

        fout.close();
        cout << "Ci values saved to " << outFile << "\n";
    }
    else if (mode == 2) {

		// Mode 2: average Ci values from multiple recordings
        string inFile;
        cout << "Enter input file name with extension: ";
        cin >> inFile;

        string outFile = replaceExtension(inFile, "_avg.txt");

        ifstream fin(inFile.c_str());
        if (!fin) {
            cerr << "Error opening " << inFile << "\n";
            return 1;
        }

        vector<vector<double>> data;
        while (true) {
            vector<double> row(LPC_ORDER);
            for (int i = 0; i < LPC_ORDER; i++) {
                if (!(fin >> row[i])) {
                    row.clear();
                    break;
                }
            }
            if (row.empty()) break;
            data.push_back(row);
        }
        fin.close();

        if (data.empty()) {
            cerr << "No data found in " << inFile << "\n";
            return 1;
        }

        vector<vector<double>> avg(5, vector<double>(LPC_ORDER, 0.0));
        for (int row = 0; row < (int)data.size(); row++) {
            int frameIdx = row % 5;
            for (int c = 0; c < LPC_ORDER; c++) {
                avg[frameIdx][c] += data[row][c];
            }
        }
        int countPerFrame = (int)data.size() / 5;
        if (countPerFrame == 0) countPerFrame = 1;
        for (int f = 0; f < 5; f++)
            for (int c = 0; c < LPC_ORDER; c++)
                avg[f][c] /= countPerFrame;

        ofstream fout(outFile.c_str());
        fout << fixed << setprecision(6);
        for (int f = 0; f < 5; f++) {
            for (int c = 0; c < LPC_ORDER; c++) fout << avg[f][c] << "\t";
            fout << "\n";
        }
        fout.close();
        cout << "Averaged Ci values written to " << outFile << "\n";
    }
    else if (mode == 3) {
        // Mode 3: recognition using Tokhura distance
        string basename;
        cout << "Enter base name for test files (e.g. 220101064_a): ";
        cin >> basename;

        // Load reference files
        const string vowels = "aeiou";
        vector<string> refNames;
        refNames.push_back("a_all_ci_avg.txt");
        refNames.push_back("e_all_ci_avg.txt");
        refNames.push_back("i_all_ci_avg.txt");
        refNames.push_back("o_all_ci_avg.txt");
        refNames.push_back("u_all_ci_avg.txt");

        vector<vector<vector<double>>> refs(5); // refs[vowel_index][row][col]
        for (int v = 0; v < 5; v++) {
            if (!readReferenceFile(refNames[v], refs[v])) {
                cerr << "Error reading reference file: " << refNames[v] << "\n";
                return 1;
            }
            // ensure each reference has 5 rows and LPC_ORDER columns
            if ((int)refs[v].size() != 5) {
                cerr << "Reference file " << refNames[v] << " must have 5 rows.\n";
                return 1;
            }
            for (int r = 0; r < 5; r++) {
                if ((int)refs[v][r].size() < LPC_ORDER) refs[v][r].resize(LPC_ORDER, 0.0);
            }
        }

        char expected = inferExpectedVowel(basename);
        if (expected == '?') {
            cout << "Warning: Couldn't infer expected vowel from basename. Recognition will still run but correctness can't be auto-checked.\n";
        } else {
            cout << "Expected vowel inferred as '" << expected << "'.\n";
        }

        int correctCount = 0;
        int processed = 0;

        for (int t = 11; t <= 20; t++) {
            
            ostringstream oss;
            oss << t;
            string testFilename = basename + "_" + oss.str() + ".txt";

            cout << "Processing " << testFilename << " ... \n";
            vector<vector<double>> testCi = computeCiForTestFile(testFilename);
            if (testCi.empty()) {
                cout << "FAILED (couldn't compute Ci)\n";
                continue;
            }

            // compute average Tokhura distance to each vowel reference
            vector<double> avgDistances(5, 0.0);
            for (int v = 0; v < 5; v++) {
                double sumDist = 0.0;
                for (int f = 0; f < 5; f++) {

                    // compare testCi[f] with refs[v][f]
                    sumDist += tokhuraDistance(testCi[f], refs[v][f]);
                }
                avgDistances[v] = sumDist / 5.0;
				cout<<"Distance from "<< vowels[v]<<" ="<<avgDistances[v]<<"\n";
            }

            // find min
            int bestIdx = 0;
            double bestVal = avgDistances[0];
            for (int v = 1; v < 5; v++) {
				
                if (avgDistances[v] < bestVal) {
                    bestVal = avgDistances[v];
                    bestIdx = v;
                }
            }
            char recognized = vowels[bestIdx];
            cout << "recognized as '" << recognized << "' (distance=" << bestVal << ")\n";

            if (expected != '?' && recognized == expected) correctCount++;
            processed++;
        }

        cout << "\nProcessed " << processed << " files. ";
        if (expected != '?') {
            cout << "Correctly recognized: " << correctCount << " out of " << processed
                 << " -> ratio = " << fixed << setprecision(3) << (double)correctCount / processed << "\n";
        } else {
            cout << "Correctness not checked (expected vowel not inferred).\n";
        }
    }
    else {
        cout << "Invalid mode.\n";
    }

    return 0;
}
