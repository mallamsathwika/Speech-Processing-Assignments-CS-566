# Vowel Recognition System

This project implements a vowel recognition system using **LPC coefficients, Cepstral analysis, and Tokhura distance**.  
The system processes recordings of vowels, extracts feature vectors, builds reference files, and performs recognition testing.

---

## Requirements

- Microsoft Visual Studio 2010 (or higher)  
- C++ compiler with standard library support  
- Input files in `.txt` format containing sampled audio data  

---

## File Naming Convention

All recordings **must** follow this naming format:

RollNo_vowel_utteranceNo.txt

Example:  
If your roll number is `254XXXXXX`, vowel is `u`, and utterance number is `7`, then: 254XXXXXX_u_7.txt


---

## Dataset Collection

1. Record **30 utterances per vowel** (`a, e, i, o, u`).  
2. Use **20 utterances for training** and **10 utterances for testing**.  
3. Trim the recordings manually using *CoolEdit* (or similar), keeping small silence before and after the vowel.  
4. Save recordings as `.txt` files with the naming convention above.  



---

## Execution Modes

The program supports **three modes**:

### **Mode 1 – Single Recording Feature Extraction**
- Input: A single recording file (e.g., `254XXXXXX_a_1.txt`).  
- Output: Extracted **Ci feature vectors** saved in a new file `<basename>_ci.txt`.  

Steps:
1. Reads input recording.  
2. Applies DC shift and normalization.  
3. Splits into frames and selects 5 steady frames.  
4. Computes LPC, Cepstral coefficients, and applies raised sine window.  
5. Saves extracted Ci values.  

---

### **Mode 2 – Reference File Generation**
- Input: A file containing Ci values of **20 recordings of the same vowel**.  
- Output: **Averaged Ci reference file** `<basename>_avg.txt`.  

Steps:
1. Reads Ci values of 20 recordings (100 rows, 12 columns).  
2. Groups them into 5 frames (20 recordings × 5 frames).  
3. Averages Ci values across recordings for each frame.  
4. Saves result as **5 rows × 12 columns** (final reference for that vowel).  

Repeat this process for all vowels `a, e, i, o, u` → resulting in 5 reference files: 
a_all_ci_avg.txt
e_all_ci_avg.txt
i_all_ci_avg.txt
o_all_ci_avg.txt
u_all_ci_avg.txt


---

### **Mode 3 – Recognition Testing**
- Input: 10 test files per vowel (e.g., `254XXXXXX_a_11.txt` to `254XXXXXX_a_20.txt`).  
- Output: Recognition result (correct/incorrect).  

Steps:
1. Extracts Ci values for each test file (5 frames).  
2. Compares with each vowel’s reference file using **Tokhura distance**.  
3. Calculates average distance across 5 frames.  
4. Recognizes the vowel with the **minimum Tokhura distance**.  
5. Displays recognition accuracy across 10 test files.  

---

## Tokhura Weights

The system uses the following Tokhura weights:

1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0

---

## Procedure Summary

1. **Training (Modes 1 & 2)**  
   - For each vowel:  
     - Process 20 recordings → extract Ci values.  
     - Average across recordings → generate reference file.  

2. **Testing (Mode 3)**  
   - For each vowel:  
     - Process 10 test recordings.  
     - Compare with all reference files using Tokhura distance.  
     - Recognize vowel with minimum distance.  
     - Compute accuracy ratio.  

---

## Example Workflow

1. Run program in **Mode 1** for each of 20 recordings of vowel `a`:  
   - Generates `*_ci.txt` files.  

2. Collect all `*_ci.txt` files into one file `a_all_ci.txt`.  

3. Run program in **Mode 2** with `a_all_ci.txt`:  
   - Produces `a_all_ci_avg.txt`.  

4. Repeat steps for vowels `e, i, o, u`.  

5. Run program in **Mode 3** with base name (e.g., `254XXXXXX_a`).  
   - Processes test recordings `*_11.txt` to `*_20.txt`.  
   - Outputs recognition results and accuracy.  

---

## Output

- `*_ci.txt` → Feature vectors from single recording  
- `*_avg.txt` → Averaged reference Ci vectors per vowel  
- Console Output → Recognition results and accuracy report  

---

## How to Run in Visual Studio

1. Open **Microsoft Visual Studio 2010**.  
2. Create a **new C++ console project**.  
3. Add the provided `.cpp` file to the project.  
4. Build and run the project.  
5. Follow on-screen prompts to select mode and provide file names.  

---

